# Chess-engine

This is a proper chess Engine wih use of AI algorithms (Min max and alpha beta pruning).
